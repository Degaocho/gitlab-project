#!/bin/bash
author:andine
echo "steps to contribute to a project on github"
echo " first I clone the remote repo to my local environment"
echo "I create a sub branch for best practice"
echo "then I make the updates on my codes"
echo " I then do a git add, git commite -m and a git push"
echo " then I assign it to a senior engineer for review"
echo "once the code is reviewed, I then sqash and merge to the main branch"
