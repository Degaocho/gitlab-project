#!/bin/bash
#Author: Engr Eric
echo "This is a script to check system analysis"
df -h
free -m
lscpu
uptime
